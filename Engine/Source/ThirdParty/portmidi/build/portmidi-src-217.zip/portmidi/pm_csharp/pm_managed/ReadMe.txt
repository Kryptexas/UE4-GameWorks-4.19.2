========================================================================
    DYNAMIC LINK LIBRARY : pm_managed Project Overview
========================================================================

AppWizard has created this pm_managed DLL for you.  

This file contains a summary of what you will find in each of the files that
make up your pm_managed application.

pm_managed.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

pm_managed.cpp
    This is the main DLL source file.

pm_managed.h
    This file contains a class declaration.

AssemblyInfo.cpp
	Contains custom attributes for modifying assembly metadata.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
