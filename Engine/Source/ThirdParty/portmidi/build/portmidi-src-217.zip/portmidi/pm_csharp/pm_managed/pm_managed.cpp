// This is the main DLL file.

#include "stdafx.h"

#include "pm_managed.h"

