Old code was removed from this directory because CMake provides an
up-to-date way to use MinGW. See portmidi/pm_mingw/README-MINGW.txt.

Roger Dannenberg
20-Sep-2010



