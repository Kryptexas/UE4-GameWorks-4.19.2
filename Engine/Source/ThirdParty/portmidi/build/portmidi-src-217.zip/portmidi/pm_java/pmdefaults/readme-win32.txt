README.txt
Roger B. Dannenberg
1 Jan 2009

This directory contains files that implement:

pmdefaults -- a program to set PortMidi default input/output devices

You can copy and rename this *whole directory* to move the application
to a convenient place. The application to run is pmdefaults.exe.

